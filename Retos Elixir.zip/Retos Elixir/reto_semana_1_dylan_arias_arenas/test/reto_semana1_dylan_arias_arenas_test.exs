defmodule RetoSemana1DylanAriasArenasTest do
  use ExUnit.Case
  doctest RetoSemana1DylanAriasArenas

  test "greets the world" do
    assert RetoSemana1DylanAriasArenas.hello() == :world
  end
end
