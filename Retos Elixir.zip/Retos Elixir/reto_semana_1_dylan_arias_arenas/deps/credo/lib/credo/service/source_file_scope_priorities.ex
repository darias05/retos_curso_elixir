defmodule Credo.Service.SourceFileScopePriorities do
  @moduledoc false

  use Credo.Service.ETSTableHelper
end
