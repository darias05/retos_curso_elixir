defmodule MainInventoryManager do
  @moduledoc """
  Módulo main para el run de la aplicación.
  """

  def main do
    InventoryManager.run()
  end
end
